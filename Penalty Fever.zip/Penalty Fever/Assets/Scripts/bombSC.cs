﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class bombSC : MonoBehaviour
{

    // Use this for initialization
    float speed_p = 10;
    float speed_t = 5;
    bool thro = false;
    float ball_x = 0;
    void Start()
    {
    }

    // Update is called once per frame
    void Update()
    {
        /*
        var platform_pos = GameObject.Find("platform").transform.position;
        if (transform.position.y == 0)
        {
            //transform.position = new Vector2((float)-0.038, (float)-5.99);
            GameObject.Find("bomb").GetComponent<Renderer>().enabled = false;
            thro = false;
        }
        if(platform_pos.x == 0 && platform_pos.y == -7)
        {
            transform.position = new Vector2((float)-0.038, (float)-5.99);
            thro = false;
            return;
        }
        if(GameObject.Find("ball").transform.position.x == 0 && GameObject.Find("ball").transform.position.y == 0)
            GameObject.Find("bomb").GetComponent<Renderer>().enabled = true;
        if (!thro)
            StartCoroutine(stay_platform());
        if (thro)
            bomb_move();
        else
            transform.position = new Vector2(platform_pos.x, (float)(platform_pos.y + 1));
        */
        var platform_pos = GameObject.Find("platform").transform.position;
        if (GameObject.Find("ball").transform.position.x == 0 && GameObject.Find("ball").transform.position.y == 0)
        {
            transform.position = new Vector2(platform_pos.x, (float)(platform_pos.y + 1));
        }

        else
        {
            if (!thro)
            {
                transform.position = new Vector2(platform_pos.x, (float)(platform_pos.y + 1));
                StartCoroutine(stay_platform());
            }
                
            else
                bomb_move();
        }
        if (transform.position.y == 0)
            Destroy(this.gameObject);
    }
    Vector2 pos;
    float time=(float)0.3;
    IEnumerator stay_platform()
    {
        
        if (!thro)
        {
            Vector2 pos1, pos2;
            pos1 = GameObject.Find("ball").transform.position;
            yield return new WaitForSeconds(time);
            pos2 = GameObject.Find("ball").transform.position;
            float m = (pos2.x - pos1.x) / (pos2.x - pos1.x);
            float c = pos2.y - m * pos2.x;
            float x1=pos2.x, y1=pos2.y,add=5;
            if (pos2.x > pos1.x)
                x1 = pos2.x + add;
            if(pos2.x < pos1.x)
                x1 = pos2.x - add;
            y1 = pos2.y + add;
            float m1 = (y1 - transform.position.y) / (x1 - transform.position.x);
            float c1 = y1 - m1 * x1;
            float y = 0;
            float x = (y - c1) / m1;
            if (!float.IsNaN(x))
                pos = new Vector2(x, y);
            else
            {
                pos = new Vector2(pos2.x,0);
            }
            if (Mathf.Abs(GameObject.Find("ball").transform.position.x)  < 1)
                pos = new Vector2(0, 0);
            thro = true;
        }
        

    }
    void bomb_move()
    {
        if(thro)
            transform.position = Vector2.MoveTowards(transform.position, pos, speed_t * Time.deltaTime);

        //transform.position = Vector2.MoveTowards(transform.position, new Vector2(ball_x, 0), speed_t * Time.deltaTime);
    }
    void OnTriggerEnter2D(Collider2D collider)
    {
        if (collider.gameObject.name == "ball")
        {
            Destroy(this.gameObject);
        }
    }
}
