﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Collections;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;

public class platformSC : MonoBehaviour {

    // Use this for initialization
    public GameObject _target;
    public GameObject _out;
    public Rigidbody2D platform;
    public float pi = (float)3.1416;
    Vector2 pos1, pos2;
    float slope;
    void Start () {
        platform = GetComponent<Rigidbody2D>();
        next_pos = GameObject.Find("platform").transform.position;
    }

    // Update is called once per frame

    
    Vector2 ball_pos;
    //Vector2 platform_pos;
    public float speed = 2;
    bool ind=true;
    bool touch = false;
    bool change_dir=true;
    bool m_ind=false;
    
    void Update () {
        var ball=GameObject.Find("ball");
        
        if (ball)
        {
            ball_pos = ball.transform.position;
        }
        //var bom = GameObject.Find("bomb(Clone)");
        if (ball_pos.x == 0 && ball_pos.y == 0)
        {
            if (!ind)
                return;
            platform.position = new Vector2(0,-7);
            GetComponent<Rigidbody2D>().velocity = Vector2.zero;
            change_dir = true;
            ind = false;
            next_pos = GameObject.Find("platform").transform.position;
            m_ind = false;
            if (!GameObject.Find("bomb(Clone)") && !GameObject.Find("bomb"))
            {
                var platform_pos = GameObject.Find("platform").transform.position;
                Instantiate(_target, new Vector2(platform_pos.x, (float)(platform_pos.y + 1)), Quaternion.identity);
            }
            return;
        }

        //platform_pos = this.transform.position;

        // StartCoroutine(getpos());
        //getpos();
        //platform_movement();
        transform.position = Vector2.MoveTowards(transform.position, new Vector2(ball_pos.x,-7), speed * Time.deltaTime);
        ind = true;    

    }
    float x = 0;
    Vector2 next_pos;
    void platform_movement()
    {
        /*
        Debug.Log("platform movement");
        float m = (pos2.y - pos1.y) / (pos2.x - pos1.x);
        int a, b;
        float c = pos2.y - m * pos2.x;
        float y = -7;
        float p_x = x;
        x = (y - c) / m;/*
        if (float.IsNaN(x))
        {
            x = p_x;
        }*/
        /*
        if (x < GameObject.Find("left").GetComponent<Rigidbody2D>().transform.position.x)
            x = GameObject.Find("left").GetComponent<Rigidbody2D>().transform.position.x;
        if (x > GameObject.Find("right").GetComponent<Rigidbody2D>().transform.position.x)
            x = GameObject.Find("right").GetComponent<Rigidbody2D>().transform.position.x;
        //Debug.Log(x);*/
        //Debug.Log("x = "+next_pos.x);
        
        float a, b;
        float m = (pos2.y - pos1.y) / (pos2.x - pos1.x);
        if (touch)
        {
            a = (int)(slope*10000);
            b = (int)(m * 10000);
            //Debug.Log(a);
            //Debug.Log(b);

            if (a == b)
                return;
            else
                touch = false;
        }
        
        transform.position = Vector2.MoveTowards(transform.position, next_pos, speed * Time.deltaTime);
        
        /*
        try
        {
            //Debug.Log(x);
            //Debug.Log(y);
            transform.position = Vector2.MoveTowards(transform.position, new Vector2(x, y), speed * Time.deltaTime);
        }catch(Exception e)
        {
            transform.position = Vector2.MoveTowards(transform.position, transform.position, speed * Time.deltaTime);
        }
		*/
        /*
        if (x > 0)
            platform.velocity = new Vector2( + speed , platform.velocity.y );
        if(x<0)
            platform.velocity = new Vector2( - speed , platform.velocity.y);
        */

    }
    
    IEnumerator getpos()
    {
        
        pos1 = GameObject.Find("ball").transform.position;
        yield return new WaitForSeconds((float)0.3);
        pos2 = GameObject.Find("ball").transform.position;
        float c, y, p_x,m;
        do
        {
            yield return new WaitForSeconds((float)0.1);
            pos2 = GameObject.Find("ball").transform.position;
            m = (pos2.y - pos1.y) / (pos2.x - pos1.x);
            c = pos1.y - m * pos1.x;
            y = -7;
            x = (y - c) / m;
            //Debug.Log(x);
        } while (float.IsNaN(x));
        
        if (x < GameObject.Find("left").GetComponent<Rigidbody2D>().transform.position.x)
            x = GameObject.Find("left").GetComponent<Rigidbody2D>().transform.position.x;
        if (x > GameObject.Find("right").GetComponent<Rigidbody2D>().transform.position.x)
            x = GameObject.Find("right").GetComponent<Rigidbody2D>().transform.position.x;
        
        next_pos = new Vector2(x, y);
        
    }
    
    Vector2 CartesianToPolar(Vector2 Cartesian)
    {
        Vector2 Polar;
        Polar.x = Mathf.Sqrt(Mathf.Pow(Cartesian.x, 2) + Mathf.Pow(Cartesian.y, 2));
        Polar.y = Mathf.Atan(Mathf.Abs(Cartesian.y / Cartesian.x));

        if (Cartesian.x < 0 && Cartesian.y > 0)
        {
            Polar.y = pi - Polar.y;
        }
        if (Cartesian.x < 0 && Cartesian.y < 0)
        {
            Polar.y = pi + Polar.y;
        }
        if (Cartesian.x > 0 && Cartesian.y < 0)
        {
            Polar.y = 2 * pi - Polar.y;
        }

        return Polar;
    }
    void OnTriggerEnter2D(Collider2D collider)
    {
        if(collider.gameObject.name == "ball")
        {
            platform.velocity = new Vector2(0, platform.velocity.y);
            touch = true;
            Debug.Log("platform collid");
            change_dir = true;
            
        }
        
    }
}
