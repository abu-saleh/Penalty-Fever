﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class ballSC : MonoBehaviour {


    void Start () {
        pre_pos = Vector2.zero;

    }
    bool direction_change = false;
    Vector2 pre_pos;
    Vector2 next_pos;
    public float pi = (float)3.1416;
    public bool ind = false;
    float speed = 5;
    float angle;
    void Update () {

        if (transform.position.x == 0 && transform.position.y == 0)
            ind = false;
        if (Input.GetMouseButtonUp(0))
        {
            next_pos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
            //angle = getangle(next_pos, pre_pos);
            setmove();
            ind = true;
        }
        
        if (ind == true)
        {
            /*
            if (direction_change)
            {
                transform.position = Vector2.MoveTowards(transform.position, next_pos, speed * Time.deltaTime);
            }
            else
                ballmove();
            */
            ballmove();
        }    
        
    }
    void ballmove()
    {
        
        Vector2 ball_pos = transform.position;
        /*
        float r = CartesianToPolar(ball_pos).x;
        next_pos.x = r + 50;
        next_pos.y = angle;
        next_pos = PolarToCartesian(next_pos);
        */
        transform.position = Vector2.MoveTowards(ball_pos, next_pos, speed * Time.deltaTime);
    }
    
    void setmove()
    {
        float m = (next_pos.y - pre_pos.y) / (next_pos.x - pre_pos.x);
        float c = next_pos.y - m * next_pos.x;
        float y = -50;
        float x= (y - c) / m;
        next_pos = new Vector2(x,y);
    }

    float getangle(Vector2 target_pos, Vector2 ball_pos)
    {
        float angle;
        angle= Mathf.Atan((target_pos.y - ball_pos.y) / (target_pos.x - ball_pos.x));
        
        if (target_pos.x < 0 && target_pos.y > 0)
            angle = pi + angle;
        
        else if (target_pos.x < 0 && target_pos.y < 0)
            angle = pi + angle;
        
        return angle;
    }


    Vector2 CartesianToPolar(Vector2 Cartesian)
    {
        Vector2 Polar;
        Polar.x = Mathf.Sqrt(Mathf.Pow(Cartesian.x, 2) + Mathf.Pow(Cartesian.y, 2));
        Polar.y = Mathf.Atan(Mathf.Abs(Cartesian.y / Cartesian.x));
        
        if (Cartesian.x <0 && Cartesian.y >0)
        {
            Polar.y =pi - Polar.y;
        }
        if (Cartesian.x < 0 && Cartesian.y < 0)
        {
            Polar.y = pi + Polar.y;
        }
        if (Cartesian.x > 0 && Cartesian.y < 0)
        {
            Polar.y = 2*pi - Polar.y;
        }
        
        return Polar;
    }
    Vector2 PolarToCartesian(Vector2 Polar)
    {
        Vector2 Cartesian;
        Cartesian.x = Polar.x * Mathf.Cos(Polar.y);
        Cartesian.y = Polar.x * Mathf.Sin(Polar.y);
        return Cartesian;
    }
    
    void OnTriggerEnter2D(Collider2D collider)
    {
        if (collider.gameObject.name == "left")
        {
            Debug.Log("left collision");
            leftset();
        }
            
        if (collider.gameObject.name == "right")
        {
            Debug.Log("right collision");
            rightset();
        }
           
        if (collider.gameObject.name == "front")
        {
			
            Debug.Log("front collision");
            this.transform.position = Vector2.zero;
            pre_pos = new Vector2(0, 0);

			//scriptText = GameObject.Find ("/Canvas/CountText").GetComponent<Text>();
			//scriptText.text = "Score";

			GameObject.Find ("Score").GetComponent<ScoreSC> ().score += 1;
            StartCoroutine(show_goal());

        }
            
        if (collider.gameObject.name == "platform")
        {
            Debug.Log("platform collision");
            this.transform.position = Vector2.zero;
            pre_pos = new Vector2(0, 0);
			GameObject.Find ("Score").GetComponent<ScoreSC> ().score = 0;
            StartCoroutine(show_out());
        }
        if (collider.gameObject.name == "bomb(Clone)" || collider.gameObject.name == "bomb")
        {
            Debug.Log("bomb collision");
            this.transform.position = Vector2.zero;
            pre_pos = new Vector2(0, 0);
            GameObject.Find("Score").GetComponent<ScoreSC>().score = 0;
            StartCoroutine(show_out());
        }

    }
    void leftset() {
        Vector2 ball_pos = transform.position;
        float angle = Mathf.Atan(Mathf.Abs((ball_pos.y - pre_pos.y) / (ball_pos.x - pre_pos.x)));
        float m = Mathf.Tan(2 * pi - angle);
        float c = ball_pos.y - m * ball_pos.x;
        float y = -50;
        float x = (y - c) / m;
        next_pos = new Vector2(x, y);
        pre_pos = ball_pos;
        direction_change = true;
    }
    void rightset()
    {
        Vector2 ball_pos = transform.position;
        float angle = Mathf.Atan(Mathf.Abs((ball_pos.y - pre_pos.y) / (ball_pos.x - pre_pos.x)));
        float m = Mathf.Tan( pi + angle);
        float c = ball_pos.y - m * ball_pos.x;
        float y = -50;
        float x = (y - c) / m;
        next_pos = new Vector2(x, y);
        pre_pos = ball_pos;
        direction_change = true;
    }
    void OnTriggerStay2D()
    {
        //Debug.Log("Stay2d");
    }
    void OnTriggerExit2D()
    {
        //Debug.Log("Exit2d");
    }
    IEnumerator show_goal()
    {
        GameObject.Find("goal").GetComponent<Renderer>().enabled = true;
        yield return new WaitForSeconds(1);
        GameObject.Find("goal").GetComponent<Renderer>().enabled = false;
    }
    IEnumerator show_out()
    {
        GameObject.Find("out").GetComponent<Renderer>().enabled = true;
        yield return new WaitForSeconds(1);
        GameObject.Find("out").GetComponent<Renderer>().enabled = false;
    }
}