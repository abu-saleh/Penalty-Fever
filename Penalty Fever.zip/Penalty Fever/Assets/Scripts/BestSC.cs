﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using System.Linq;
using UnityEngine.UI;
using System.IO;
public class BestSC : MonoBehaviour {

	// Use this for initialization
	int cur_scr,cur_best;
	string file = "best_score.txt";

	void Start () {
		if (!File.Exists (file)) {
			using (System.IO.StreamWriter write_best =
				       new System.IO.StreamWriter (file, true)) {
				write_best.WriteLine ("0");
			}
		}
	}
	
	// Update is called once per frame
	void Update () {
		cur_scr = GameObject.Find ("Score").GetComponent<ScoreSC> ().score;
		string sc;

		using (System.IO.StreamReader read_best = new System.IO.StreamReader (file, true)) {
				sc = read_best.ReadLine();
				cur_best = Int16.Parse (sc);
				GameObject.Find ("Best").GetComponent<Text> ().text = "Best : " + cur_best.ToString ();
			}
		

		if(cur_scr > cur_best){
			
			File.Delete (file);
			using (System.IO.StreamWriter write_best =
			new System.IO.StreamWriter(file, true))
			{
				write_best.WriteLine(cur_scr);
			}

		}

		//Debug.Log ("best score");
	}
}
