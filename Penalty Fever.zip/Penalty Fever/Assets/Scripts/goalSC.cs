﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class goalSC : MonoBehaviour {

    // Use this for initialization
    public bool show = false;
	void Start () {
        GameObject.Find("goal").GetComponent<Renderer>().enabled = false;
    }
	
	// Update is called once per frame
	void Update () {
        

	}
}
